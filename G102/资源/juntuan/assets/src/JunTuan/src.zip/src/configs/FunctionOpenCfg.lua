--本地功能开启表，目前只设置入口的显隐


local FunctionOpenCfg = {
    --图鉴
    MONSTERBOOK_OPEN = true,
    --里程碑
    MILESTONE_OPEN = true,
    --每日任务
    TASKDAILY_OPEN = true,
    --七日签到
    SIGN_SEVENS_OPEN = true,
    --设置
    SETTINGS_OPEN = true,
    --离线收益
    OFFLINECOIN_OPEN = true,
    --孵蛋
    PETPANEL_OPEN = false,
}


return FunctionOpenCfg