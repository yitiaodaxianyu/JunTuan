local ShopCfg = {};

ShopCfg.ExArr = {
    {
        cost = 50,
        coin = 2500
    }
    ,{
        cost = 50,
        energy = 5
    }
}


ShopCfg.EnergyExTimesMax = 10;

return ShopCfg
